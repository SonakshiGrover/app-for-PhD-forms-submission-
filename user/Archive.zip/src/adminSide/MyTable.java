package adminSide;
import data_manager.Registration;

import java.awt.Desktop;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.stage.Stage;
import javafx.util.Callback;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.chart.PieChart;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.application.Application;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TablePosition;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.application.Application;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.scene.input.MouseEvent;
 
public class MyTable extends Application 
{
	private final TableView<TableModel> table = new TableView<>();
	
	private final ObservableList<TableModel> data =  FXCollections.observableArrayList(/*new TableModel("as","qadc", "aD")*/ );
	
    public void start(Stage stage,ArrayList<Registration> FilteredResult) {
    	
        Scene scene = new Scene(new Group());
        stage.setTitle("Filtered Result");
        stage.setWidth(550);
        stage.setHeight(470);
        
        final Label label = new Label("Filtered Result");
        label.setFont(new Font("Arial", 20));
        String[] str = new String[3];
        
	      for(Registration r:FilteredResult)
	      {
	    	  str[0]=r.getEnrollmentNumber();
	    	  str[1]=r.getName();
	    	  str[2]= "src/dbData/registration_html_files/" +  r.getEnrollmentNumber() + ".html" ;
	    	  System.out.println("data for table    "+ r.getEnrollmentNumber()+" "+r.getName()+" link to data"); 
	          data.add(new TableModel(str[0],str[1],str[2] ));
	        		                        	   
	      } 			                       
        		                           
         
       
 
        table.setEditable(false);
        
 
        TableColumn EnrollID = new TableColumn("Enrollment ID");
        EnrollID.setMinWidth(100);
        EnrollID.setCellValueFactory(
                new PropertyValueFactory<>("enrollmentNumber"));
 
        TableColumn Name = new TableColumn("Name");
        Name.setMinWidth(200);
        Name.setCellValueFactory(
                new PropertyValueFactory<>("name"));
        
        
      
        TableColumn Linktodata = new TableColumn("Link To Data");
        Linktodata.setMinWidth(200);
        Linktodata.setCellValueFactory( new PropertyValueFactory<>("Linktodata"));
        Linktodata.setSortable(false);
        

        table.setItems(data); // link the table to the dataa
        table.getColumns().addAll(EnrollID, Name, Linktodata);
        
        // working code on click row
        //table.getSelectionModel().setCellSelectionEnabled(true); 
        table.setOnMousePressed(new EventHandler<MouseEvent>() {
            @Override 
            public void handle(MouseEvent event) {
                if (event.isPrimaryButtonDown() && event.getClickCount() == 1) {
                	TablePosition pos = table.getSelectionModel().getSelectedCells().get(0);
                	int row = pos.getRow();
                	int col = pos.getColumn();
                	
                	if(col == 2)
                	{
                		openLinkToData( data.get(row).getLinktodata() );
                	}
                                     
                }
            }
        });
//        
      
        
 
        final VBox vbox = new VBox();
        vbox.setSpacing(5);
        vbox.setPadding(new Insets(10, 0, 0, 10));
        vbox.getChildren().addAll(label,table);
 
        
        ((Group) scene.getRoot()).getChildren().addAll(vbox);
 
        stage.setScene(scene);
        stage.show();
    }

	@Override
	public void start(Stage primaryStage) throws Exception {
		// TODO Auto-generated method stub
		
	}
	
	void openLinkToData(String link)
	{
		File a = new File(link);
		System.out.println(a.getAbsolutePath());
		try
		{
			 Desktop.getDesktop().open(a);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
}

    
 


