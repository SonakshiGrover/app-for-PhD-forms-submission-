package adminSide;

import javafx.beans.property.SimpleStringProperty;

public class TableModel 
{

    SimpleStringProperty  enrollmentNumber;

    SimpleStringProperty  name;
    
    SimpleStringProperty linktodata;

	
	public TableModel( String enrollmentNumber,String name,String Linktodata)
	{
		
		this.enrollmentNumber=new SimpleStringProperty(enrollmentNumber);
		this.name=new SimpleStringProperty(name);
		
		this.linktodata=new SimpleStringProperty(Linktodata);

	}
	
	
	public String getEnrollmentNumber()
	{
		return enrollmentNumber.get();
		
	}
	public void setEnrollmentNumber(String v)
	{
		enrollmentNumber.set(v);
		
	}
	public String getName()
	{
		return name.get();
		
	}
	

	public void setName(String v)
	{
		name.set(v);
		
	}
	
	public String getLinktodata()
	{
		return linktodata.get();
	}
	
	public void setLinktodata(String v)
	{
		linktodata.set(v);
	}
	
	
	
}
