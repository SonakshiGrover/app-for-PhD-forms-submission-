package adminSide;

import java.time.LocalDate;

import javafx.scene.control.DatePicker;

public class FilterParams
{
//	FILTER variables
	
	String reqdEmail;    
	String reqdName;
	String reqdEnrollmentNo;
	String reqdCategory;
	String reqdGender;
	String reqdphyDisabled;
	String time;
	LocalDate refdob;           // time = before,on,after
	String reqdphdstream;
	String reqdgraddegree;
	String reqdpostdgraddegree;
	String reqdclassXboard;
	String reqdclassXIIboard;
	String reqdDepartmentgrad;
	String reqdDepartmentpostgrad;
	String reqdUniversitygrad;
	String reqdUniversitypostgrad;
	String reqdStategradfrom;
	String reqdStategradpostfrom;
    double refXperc;	
    double refXIIperc;
    double refGradperc;
    double refpostGradperc;	
    double refGATEscore;
    String Xcompare1,Xcompare2,Xcompare3,XIIcompare1,XIIcompare2,XIIcompare3,Gradcompare1,Gradcompare2,Gradcompare3,postGradcompare1,postGradcompare2,postGradcompare3,GATEcompare1,GATEcompare2,GATEcompare3;
    
    String Xcompare,XIIcompare,Gradcompare,postGradcompare,GATEcompare;
    LocalDate Applicationdatedfrom,Applicationdatedupto;
	public String getReqdEmail() {
		return reqdEmail;
	}
	public void setReqdEmail(String reqdEmail) {
		this.reqdEmail = reqdEmail;
	}
	public String getReqdName() {
		return reqdName;
	}
	public void setReqdName(String reqdName) {
		this.reqdName = reqdName;
	}
	public String getReqdEnrollmentNo() {
		return reqdEnrollmentNo;
	}
	public void setReqdEnrollmentNo(String reqdEnrollmentNo) {
		this.reqdEnrollmentNo = reqdEnrollmentNo;
	}
	public String getReqdCategory() {
		return reqdCategory;
	}
	public void setReqdCategory(String reqdCategory) {
		this.reqdCategory = reqdCategory;
	}
	public String getReqdGender() {
		return reqdGender;
	}
	public void setReqdGender(String reqdGender) {
		this.reqdGender = reqdGender;
	}
	public String getReqdphyDisabled() {
		return reqdphyDisabled;
	}
	public void setReqdphyDisabled(String reqdphyDisabled) {
		this.reqdphyDisabled = reqdphyDisabled;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public LocalDate getRefdob() {
		return refdob;
	}
	public void setRefdob(LocalDate refdob) {
		this.refdob = refdob;
	}
	public String getReqdphdstream() {
		return reqdphdstream;
	}
	public void setReqdphdstream(String reqdphdstream) {
		this.reqdphdstream = reqdphdstream;
	}
	public String getReqdgraddegree() {
		return reqdgraddegree;
	}
	public void setReqdgraddegree(String reqdgraddegree) {
		this.reqdgraddegree = reqdgraddegree;
	}
	public String getReqdpostdgraddegree() {
		return reqdpostdgraddegree;
	}
	public void setReqdpostdgraddegree(String reqdpostdgraddegree) {
		this.reqdpostdgraddegree = reqdpostdgraddegree;
	}
	public String getReqdclassXboard() {
		return reqdclassXboard;
	}
	public void setReqdclassXboard(String reqdclassXboard) {
		this.reqdclassXboard = reqdclassXboard;
	}
	public String getReqdclassXIIboard() {
		return reqdclassXIIboard;
	}
	public void setReqdclassXIIboard(String reqdclassXIIboard) {
		this.reqdclassXIIboard = reqdclassXIIboard;
	}
	public String getReqdDepartmentgrad() {
		return reqdDepartmentgrad;
	}
	public void setReqdDepartmentgrad(String reqdDepartmentgrad) {
		this.reqdDepartmentgrad = reqdDepartmentgrad;
	}
	public String getReqdDepartmentpostgrad() {
		return reqdDepartmentpostgrad;
	}
	public void setReqdDepartmentpostgrad(String reqdDepartmentpostgrad) {
		this.reqdDepartmentpostgrad = reqdDepartmentpostgrad;
	}
	public String getReqdUniversitygrad() {
		return reqdUniversitygrad;
	}
	public void setReqdUniversitygrad(String reqdUniversitygrad) {
		this.reqdUniversitygrad = reqdUniversitygrad;
	}
	public String getReqdUniversitypostgrad() {
		return reqdUniversitypostgrad;
	}
	public void setReqdUniversitypostgrad(String reqdUniversitypostgrad) {
		this.reqdUniversitypostgrad = reqdUniversitypostgrad;
	}
	public String getReqdStategradfrom() {
		return reqdStategradfrom;
	}
	public void setReqdStategradfrom(String reqdStategradfrom) {
		this.reqdStategradfrom = reqdStategradfrom;
	}
	public String getReqdStategradpostfrom() {
		return reqdStategradpostfrom;
	}
	public void setReqdStategradpostfrom(String reqdStategradpostfrom) {
		this.reqdStategradpostfrom = reqdStategradpostfrom;
	}
	public double getRefXperc() {
		return refXperc;
	}
	public void setRefXperc(double refXperc) {
		this.refXperc = refXperc;
	}
	public double getRefXIIperc() {
		return refXIIperc;
	}
	public void setRefXIIperc(double refXIIperc) {
		this.refXIIperc = refXIIperc;
	}
	public double getRefGradperc() {
		return refGradperc;
	}
	public void setRefGradperc(double refGradperc) {
		this.refGradperc = refGradperc;
	}
	public double getRefpostGradperc() {
		return refpostGradperc;
	}
	public void setRefpostGradperc(double refpostGradperc) {
		this.refpostGradperc = refpostGradperc;
	}
	public double getRefGATEscore() {
		return refGATEscore;
	}
	public void setRefGATEscore(double refGATEscore) {
		this.refGATEscore = refGATEscore;
	}
	public String getXcompare() {
		return Xcompare;
	}
	public void setXcompare(String xcompare) {
		Xcompare = xcompare;
	}
	public String getXIIcompare() {
		return XIIcompare;
	}
	public void setXIIcompare(String xIIcompare) {
		XIIcompare = xIIcompare;
	}
	public String getGradcompare() {
		return Gradcompare;
	}
	public void setGradcompare(String gradcompare) {
		Gradcompare = gradcompare;
	}
	public String getPostGradcompare() {
		return postGradcompare;
	}
	public void setPostGradcompare(String postGradcompare) {
		this.postGradcompare = postGradcompare;
	}
	public String getGATEcompare() {
		return GATEcompare;
	}
	public void setGATEcompare(String gATEcompare) {
		GATEcompare = gATEcompare;
	}
	public LocalDate getApplicationdatedfrom() {
		return Applicationdatedfrom;
	}
	public void setApplicationdatedfrom(LocalDate applicationdatedfrom) {
		Applicationdatedfrom = applicationdatedfrom;
	}
	public LocalDate getApplicationdatedupto() {
		return Applicationdatedupto;
	}
	public void setApplicationdatedupto(LocalDate applicationdatedupto) {
		Applicationdatedupto = applicationdatedupto;
	}
    
    
	
}

