package adminSide;



import java.net.URL;
import java.util.ArrayList;
import java.util.Observable;
import java.util.ResourceBundle;



import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import data_manager.*;


public class AdminController implements Initializable
{

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private RadioButton Before;

    @FXML
    private ComboBox<String> GradDepartment;

    @FXML
    private TextField PostGradUniv;

    @FXML
    private TextField Email;

    @FXML
    private ComboBox<String> Category;

    @FXML
    private CheckBox LTPostGrad;

    @FXML
    private CheckBox LTGrad;

    @FXML
    private RadioButton Yes;

    @FXML
    private CheckBox EClassX;

    @FXML
    private RadioButton Male;

    @FXML
    private CheckBox LTClassXII;

    @FXML
    private DatePicker AppDtatedUpto;

    @FXML
    private TextField Name;

    @FXML
    private CheckBox LTClassX;

    @FXML
    private CheckBox GTGATE;

    @FXML
    private DatePicker DOB;

    @FXML
    private CheckBox EPostGrad;

    @FXML
    private Button ShowFilteredResultBtn;

    @FXML
    private RadioButton Female;

    @FXML
    private CheckBox EGrad;

    @FXML
    private CheckBox GTPostGrad;

    @FXML
    private CheckBox GTClassX;

    @FXML
    private ComboBox<String> ClassXBoard;

    @FXML
    private RadioButton No;

    @FXML
    private CheckBox LTGATE;

    @FXML
    private ComboBox<String> PostGradState;

    @FXML
    private DatePicker AppDatedFrom;

    @FXML
    private ComboBox<String> GradState;

    @FXML
    private TextField EnrollmentNo;

    @FXML
    private CheckBox GTGrad;

    @FXML
    private ComboBox<String> PostGradDepartment;

    @FXML
    private ComboBox<String> ClassXIIBoard;

    @FXML
    private CheckBox EClassXII;

    @FXML
    private ComboBox<String> PostGradDegree;

    @FXML
    private RadioButton After;

    @FXML
    private ComboBox<String> PHDstream;

    @FXML
    private ComboBox<String> GradDegree;

    @FXML
    private TextField GradUniv;

    @FXML
    private CheckBox EGATE;

    @FXML
    private RadioButton On;

    @FXML
    private CheckBox GTClassXII;
    
    @FXML
    private TextField GATEscore;
    

    @FXML
    private TextField Xperc;
    

    @FXML
    private TextField XIIperc;
    

    @FXML
    private TextField Gradperc;
    

    @FXML
    private TextField PostGradperc;
    
    
    ObservableList<String> options1=
    		FXCollections.observableArrayList(
    
    	"General",
    	"SC",
    	"ST",
    	"OBC"
    		
    		
    		
    );
    
    ObservableList<String> options2=
    		FXCollections.observableArrayList
    		(
    				"Computer Science",
                    "Electronics and Communication",
                    "Computational Biology"
            );
    
    ObservableList<String> options3=
    		FXCollections.observableArrayList
    		(
    				"Andaman and Nicobar Islands",
                    "Andhra Pradesh",
                    "Arunachal Pradesh",
                    "Assam",
                    "Bihar",
                    "Chandigarh",
                     "Chhatisgarh",
                     "Dadra and Nagar Haveli",
                     "Daman and Diu",
                     "Delhi",
                     "Goa",
                      "Gujarat",
                     "Haryana",
                     "Himachal Pradesh",
                     "Jammu and Kashmir",
                     "Jharkhand",
                     "Karnataka",
                      "Kerala",
                      "Lakshadweep",
                      "Madhya Pradesh",
                      "Maharashtra",
                      "Manipur",
                      "Meghalaya",
                      "Mizoram",
                      "Nagaland",
                       "Orissa",
                     "Pondicherry",
                      "Punjab",
                      "Rajasthan",
                      "Sikkim",
                      "Tamil Nadu",
                       "Tripura",
                      "Uttaranchal",
                     "Uttar Pradesh",
                      "West Bengal" ,
                      "Other"

            );
    
    ObservableList<String> xBoardList= FXCollections.observableArrayList( );
    ObservableList<String> xiiBoardList= FXCollections.observableArrayList( );
    ObservableList<String> gDeptList= FXCollections.observableArrayList( );
    ObservableList<String> pgDeptList= FXCollections.observableArrayList( );
    ObservableList<String> gDegList= FXCollections.observableArrayList( );
    ObservableList<String> pgDegList= FXCollections.observableArrayList( );
    
    
    @FXML
    void startFilter(ActionEvent ShowFilteredResultBtn)
    {
    	
    	System.out.println("startFilter started");
    	
    	
    	//System.out.println(DataManager.readFromFile(0));
          
        ////////////Putting all the data to p
    	
    	FilterParams p=new FilterParams();
        
    	
    		p.reqdEmail=Email.getText();
    	
    		System.out.println("startFilter started 1");	
    		
    		p.reqdName=Name.getText();
    	 
    		System.out.println("startFilter started 2");
    	
    		p.reqdEnrollmentNo=EnrollmentNo.getText();
    	
    		System.out.println("startFilter started 3");
    		
    		if(Category.getValue()==null)
    			p.reqdCategory="";	
    		else
    			p.reqdCategory=(String) Category.getValue();     
    		
    		System.out.println("startFilter started 4");
    	
	//Gender
	if(Male.isSelected())
		 p.reqdGender="Male";
	else
	if(Female.isSelected())
		p.reqdGender="Female";
	else
		p.reqdGender="";  
	
	System.out.println("startFilter started 5");
	
	//physically disabled
	if(Yes.isSelected())
		 p.reqdphyDisabled="Yes";
	else
	if(No.isSelected())
		p.reqdphyDisabled="No";
	else
		p.reqdphyDisabled=""; 
	
	System.out.println("startFilter started 6");	
	//Date Of Birth
	if(Before.isSelected())
		 p.time="Before";
	else
	if(On.isSelected())
		p.time="On";
	else
	if(After.isSelected())	
		p.time="After"; 
	else
		p.time="";
	
	System.out.println("startFilter started 7");  
	p.refdob=DOB.getValue();
	
	System.out.println("startFilter started 8");
	
	if(PHDstream.getValue()==null)
		p.reqdphdstream="";	
	else
	p.reqdphdstream=(String) PHDstream.getValue();
	
	System.out.println("startFilter started 9");
	
	if(GradDegree.getValue()==null)
		p.reqdgraddegree="";	
	else
	    p.reqdgraddegree=(String) GradDegree.getValue();
	
	System.out.println("startFilter started 10"); 
	
	if(PostGradDegree.getValue()==null)
		p.reqdpostdgraddegree="";	
	else
		p.reqdpostdgraddegree=(String) PostGradDegree.getValue();
	
	System.out.println("startFilter started 11");
	
	if(ClassXBoard.getValue()==null)
		p.reqdclassXboard="";	
	else
		p.reqdclassXboard=(String) ClassXBoard.getValue();
	
	System.out.println("startFilter started 12"); 
	
	if(ClassXIIBoard.getValue()==null)
		p.reqdclassXIIboard="";	
	else
		p.reqdclassXIIboard=(String) ClassXIIBoard.getValue();
	
	System.out.println("startFilter started 13");
	
	if(GradDepartment.getValue()==null)
		p.reqdDepartmentgrad="";	
	else
		p.reqdDepartmentgrad=(String) GradDepartment.getValue();
	
	System.out.println("startFilter started 14");
	
	if(PostGradDepartment.getValue()==null)
		p.reqdDepartmentpostgrad="";	
	else
		p.reqdDepartmentpostgrad=(String) PostGradDepartment.getValue();
	
	System.out.println("startFilter started 15");
	
	
	p.reqdUniversitygrad=GradUniv.getText();
	
	System.out.println("startFilter started 16");
	p.reqdUniversitypostgrad=PostGradUniv.getText();
	
	System.out.println("startFilter started 17");
	if(GradState.getValue()==null)
		p.reqdStategradfrom="";	
	else
		p.reqdStategradfrom=(String) GradState.getValue();
	
	System.out.println("startFilter started 18");
	
	if(PostGradState.getValue()==null)
		p.reqdStategradpostfrom="";	
	else
	    p.reqdStategradpostfrom=(String) PostGradState.getValue();
	
	//CLASS X
		
	if(GTClassX.isSelected())
		p.Xcompare1="Greater Than";
	else
		p.Xcompare1="";
		
	
	
	if(EClassX.isSelected())
		p.Xcompare2="Equals";
	else
		p.Xcompare2="";
	
	
	if(LTClassX.isSelected())
		p.Xcompare3="Lesser Than";
	else
		p.Xcompare3="";
	
	
	if(Xperc.getText().equals(""))
		p.refXperc=-1;
	else
	p.refXperc=Double.parseDouble(Xperc.getText());	
    
	System.out.println("startFilter started 19");

	
	//CLASS XII
	if(GTClassXII.isSelected())
		p.XIIcompare1="Greater Than";
	else
		p.XIIcompare1="";
	
	
	if(EClassXII.isSelected())
		p.XIIcompare2="Equals";
	else
		p.XIIcompare2="";

	
	if(LTClassXII.isSelected())
		p.XIIcompare3="Lesser Than";
	else
		p.XIIcompare3="";
	
	System.out.println("startFilter started 20");
	if(XIIperc.getText().equals(""))
		p.refXIIperc=-1;
	else
	p.refXIIperc=Double.parseDouble(XIIperc.getText());
	
    
	//GRAD
		if(GTGrad.isSelected())
			p.Gradcompare1="Greater Than";
		else
			p.Gradcompare1="";
		
		if(EGrad.isSelected())
			p.Gradcompare2="Equals";
		else
			p.Gradcompare2="";
		
		if(LTGrad.isSelected())
			p.Gradcompare3="Lesser Than";
		else
			p.Gradcompare3="";
	
		System.out.println("startFilter started 21");	
		if(Gradperc.getText().equals(""))
			p.refGradperc=-1;
		else
	        p.refGradperc=Double.parseDouble(Gradperc.getText());
		  
		
	//POST GRAD
		if(GTPostGrad.isSelected())
			p.postGradcompare1="Greater Than";
		else
			p.postGradcompare1="";
		
	    if(EPostGrad.isSelected())
		    p.postGradcompare2="Equals";
	    else
	    	p.postGradcompare2="";
		   
	  
	    if(LTPostGrad.isSelected())
		    p.postGradcompare3="Lesser Than";
	    else
		    p.postGradcompare3="";

		System.out.println("startFilter started 22");	
		if(PostGradperc.getText().equals(""))
			p.refpostGradperc=-1;
		else
	       p.refpostGradperc=Double.parseDouble(PostGradperc.getText());	
		   	
	//GATE Score
		if(GTGATE.isSelected())
			p.GATEcompare1="Greater Than";
		else
			p.GATEcompare1="";
		
	    if(EGATE.isSelected())
			p.GATEcompare2="Equals";
	   else
		   p.GATEcompare2="";
	    
	    
		if(LTGATE.isSelected())
		    p.GATEcompare3="Lesser Than";
		else
		    p.GATEcompare3="";
		
		if(GATEscore.getText().equals(""))
			p.refGATEscore=-1;
		else
	        p.refGATEscore=Double.parseDouble(GATEscore.getText());
		  		
	 System.out.println("startFilter started 23");
	 p.Applicationdatedfrom=AppDatedFrom.getValue();
	
	 p.Applicationdatedupto=AppDtatedUpto.getValue();
	 
	 System.out.println("startFilter started 24");
	DataFilter d = new DataFilter();
	 System.out.println("startFilter started 25");
		
	 ArrayList<Registration> FilteredResult =new ArrayList<Registration>();
	 System.out.println("startFilter started 26");
		
	
	FilteredResult=d.doFilter(p);
	 System.out.println("startFilter started 27");
	
	 
	         //System.out.println("adios");
	        
	    	Stage PrimaryStage= new Stage();
	    	MyTable tb=new MyTable();
	    	tb.start(PrimaryStage,FilteredResult);
	    	
	    	System.out.println("startFilter started 28");
	    	  

	 }
    
    
    void setComboBoxes() // function to get a set of data
    {
    	ArrayList<Registration> allRegs = data_manager.DataManager.getAllRegistrations();
    	
    	for(Registration r : allRegs)
    	{
    		 if( xBoardList.contains(r.getClassXBoardName()) == false)    xBoardList.add(r.getClassXBoardName());
    		 if( xiiBoardList.contains(r.getClassXIIBoardName()) == false)    xiiBoardList.add(r.getClassXIIBoardName());
    		 if( gDeptList.contains(r.getGraduationDepartment()) == false)    gDeptList.add(r.getGraduationDepartment());
    		 if( pgDeptList.contains(r.getPgGraduationDepartment()) == false)    pgDeptList.add(r.getPgGraduationDepartment());
    		 if( gDegList.contains(r.getGraguationDegree()) == false)    gDegList.add(r.getGraguationDegree());
    		 if( pgDegList.contains(r.getPgGraguationDegree()) == false)    pgDegList.add(r.getPgGraguationDegree());
    	}
    	
    }


	@Override
	public void initialize(URL arg0, ResourceBundle arg1) 
	{
		  setComboBoxes();
			
		  Category.setItems(options1);
		  PHDstream.setItems(options2);
		  GradState.setItems(options3);
		  PostGradState.setItems(options3);	
		  ClassXBoard.setItems(xBoardList);
		  ClassXIIBoard.setItems(xiiBoardList);
		  GradDepartment.setItems(gDeptList);
		  PostGradDepartment.setItems(pgDeptList);
		  PostGradDegree.setItems(pgDegList);
		  GradDegree.setItems(gDegList);
	  
	}
    


}





