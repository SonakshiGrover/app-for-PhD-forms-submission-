package adminSide;

import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.io.Serializable;


import java.util.ArrayList;

import data_manager.Registration;

public class DataFilter 
{
	

	boolean singleFilter( Registration regData ,  FilterParams Params )
	{

				
		        boolean b1,b2,b3,b4,b5,b6,b7,b8,b9,b10,b11,b12,b13,b14,b15,b16,b17,b18,b19,b20,b21,b22,b23,b24;
        
				
				// assuming that every field's value is already converted to string and then passed to this function
				//  and if the admin does not apply filter to a field then the field's value passed to this function is null
		
		        System.out.println("single Filter started 1");
		        
				b1=Params.reqdEmail.trim().isEmpty() || regData.getEmail().equals(Params.reqdEmail);
		        b2=Params.reqdName.trim().isEmpty() || regData.getName().equals(Params.reqdName);
				b3=Params.reqdEnrollmentNo.trim().isEmpty() || regData.getEnrollmentNumber().equals(Params.reqdEnrollmentNo);
				b4=Params.reqdCategory.trim().isEmpty() || regData.getCategory().equals(Params.reqdCategory);
				b5=Params.reqdGender.trim().isEmpty() || regData.getGender().equals(Params.reqdGender);
				b6=Params.reqdphyDisabled.trim().isEmpty() || ((regData.getPhysicallyDisabled()==true)&&(Params.reqdphyDisabled.equals("Yes")))||((regData.getPhysicallyDisabled()==false)&&(Params.reqdphyDisabled.equals("No")));
				
				
				System.out.println("........"+".....b6= ......"+b6+ "....."+Params.reqdphyDisabled.trim().isEmpty()+".... "+regData.getPhysicallyDisabled() +"......"+Params.reqdphyDisabled.equals("Yes")+"..."+(regData.getPhysicallyDisabled()==false)+"..."+(Params.reqdphyDisabled.equals("No"))+"\n");
				System.out.println("single Filter started 2");
				
				
				if(Params.time.trim().isEmpty())
					b7=true;
				/*else
				if(regData.dataoOfBirth.getValue()==null)
					b7=true;
				*/
				else
				if(Params.time.equals("Before")  &&  regData.getDataoOfBirth().isBefore(Params.refdob))    ////check
					b7=true;
				else
			    if(Params.time.equals("On")  &&   regData.getDataoOfBirth().isEqual(Params.refdob))    ////check
					b7=true;
				else
				if(Params.time.equals("After") &&  regData.getDataoOfBirth().isAfter(Params.refdob))   ////check
				    b7=true;
				else
					b7=false;
				
				System.out.println("single Filter started 3");
				b8=Params.reqdphdstream.trim().isEmpty() ||  regData.getPhsStream().equals(Params.reqdphdstream);
				b9=Params.reqdgraddegree.trim().isEmpty() || regData.getGraguationDegree().equals(Params.reqdgraddegree);
				b10=Params.reqdpostdgraddegree.trim().isEmpty() || regData.getPgGraguationDegree().equals(Params.reqdpostdgraddegree);
				
				//System.out.println("$$$$$$$$$$$reqd = "+Params.reqdclassXboard + "right now = "+ regData.getClassXBoardMarks());
				
				b11=Params.reqdclassXboard.trim().isEmpty() || regData.getClassXBoardName().equals(Params.reqdclassXboard);
				b12=Params.reqdclassXIIboard.trim().isEmpty() || regData. getClassXIIBoardName().equals(Params.reqdclassXIIboard);
				b13=Params.reqdDepartmentgrad.trim().isEmpty() || regData.getGraduationDepartment().equals(Params.reqdDepartmentgrad);
				b14=Params.reqdDepartmentpostgrad.trim().isEmpty() || regData.getPgGraduationDepartment().equals(Params.reqdDepartmentpostgrad);
				b15=Params.reqdUniversitygrad.trim().isEmpty() || ((regData.getUniversityName()!=null)&&(regData.getUniversityName().equals(Params.reqdUniversitygrad)));
				b16=Params.reqdUniversitypostgrad.trim().isEmpty() ||((regData.getPguniversityName()!=null)&&(regData.getPguniversityName().equals(Params.reqdUniversitypostgrad)));
				b17=Params.reqdStategradfrom.trim().isEmpty() || regData.getGraduationState().equals(Params.reqdStategradfrom);/////???
				b18=Params.reqdStategradpostfrom.trim().isEmpty() ||(regData.getPgGraduationState()!=null)&&( regData.getPgGraduationState().equals(Params.reqdStategradpostfrom));
			
				System.out.println("single Filter started 4");
				
				///////////
				b19=false;
				
				if(Double.compare(Params.refXperc, -1)==0)
					b19=true;
				else if(Params.Xcompare1.trim().isEmpty() && Params.Xcompare2.trim().isEmpty() && Params.Xcompare3.trim().isEmpty())
					b19=true;
				else
				{
					
					if((Params.Xcompare1.equals("Greater Than"))&&(Double.compare(regData.getClassXBoardMarks(),Params.refXperc)>0))
					{
						b19 =true;
					}
					
				    if(	Params.Xcompare2.equals("Equals")  && ( Double.compare(regData.getClassXBoardMarks(),Params.refXperc)==0))
				    {
				    	System.out.print("hohohoh" + Double.compare(regData.getClassXBoardMarks(),Params.refXperc));
				    	b19=true;
				    }
					
				    if(	(Params.Xcompare3.equals("Lesser Than"))  &&( Double.compare(regData.getClassXBoardMarks(), Params.refXperc) <0))
				    {
				    	b19=true;
				    }
				
				
				}
				
				///////////////
				
				b20=false;
				
				if(Double.compare(Params.refXIIperc, -1)==0)
					b20=true;
				else if(Params.XIIcompare1.trim().isEmpty() && Params.XIIcompare2.trim().isEmpty() && Params.XIIcompare3.trim().isEmpty())
					b20=true;
				else
				{
					
					if((Params.XIIcompare1.equals("Greater Than"))&&(Double.compare(regData.getClassXIIBoardMarks(),Params.refXIIperc)>0))
					{
						b20 =true;
					}
					
				    if(	Params.XIIcompare2.equals("Equals")  && ( Double.compare(regData.getClassXIIBoardMarks(),Params.refXIIperc)==0))
				    {
				    	b20=true;
				    }
					
				    if(	(Params.XIIcompare3.equals("Lesser Than"))  &&( Double.compare(regData.getClassXIIBoardMarks(), Params.refXIIperc) <0))
				    {
				    	b20=true;
				    }
				
				
				}
				
                 b21=false;
				
				if(Double.compare(Params.refGradperc, -1)==0)
					b21=true;
				else if(Params.Gradcompare1.trim().isEmpty() && Params.Gradcompare2.trim().isEmpty() && Params.Gradcompare3.trim().isEmpty())
					b21=true;
				else
				{
					
					if((Params.Gradcompare1.equals("Greater Than"))&&(Double.compare(regData.getGraduationMarks(),Params.refGradperc)>0))
					{
						b21 =true;
					}
					
				    if(	Params.Gradcompare2.equals("Equals")  && ( Double.compare(regData.getGraduationMarks(),Params.refGradperc)==0))
				    {
				    	b21=true;
				    }
					
				    if(	(Params.Gradcompare3.equals("Lesser Than"))  &&( Double.compare(regData.getGraduationMarks(), Params.refGradperc) <0))
				    {
				    	b21=true;
				    }
				
				
				}
				
			
				
				System.out.println("single doFilter started 9");
				
				 b22=false;
					
					if(Double.compare(Params.refpostGradperc, -1)==0)
						b22=true;
					else if(Params.postGradcompare1.trim().isEmpty() && Params.postGradcompare2.trim().isEmpty() && Params.postGradcompare3.trim().isEmpty())
						b22=true;
					else
					{
						
						if((Params.postGradcompare1.equals("Greater Than"))&&(regData.getPgGraduationMarks()!=null)&&(Double.compare(regData.getPgGraduationMarks(),Params.refpostGradperc)>0))
						{
							b22 =true;
						}
						
					    if(	(Params.postGradcompare2.equals("Equals"))  &&(regData.getPgGraduationMarks()!=null)&& ( Double.compare(regData.getPgGraduationMarks(),Params.refpostGradperc)==0))
					    {
					    	b22=true;
					    }
						
					    if(	(Params.postGradcompare3.equals("Lesser Than"))  &&(regData.getPgGraduationMarks()!=null)&&( Double.compare(regData.getPgGraduationMarks(), Params.refpostGradperc) <0))
					    {
					    	b22=true;
					    }
					
					
					}
									
					System.out.println("single doFilter started 9");
					
					 b24=false;
						
						if(Double.compare(Params.refGATEscore, -1)==0)
							b24=true;
						else if(Params.GATEcompare1.trim().isEmpty() && Params.GATEcompare2.trim().isEmpty() && Params.GATEcompare3.trim().isEmpty())
							b24=true;
						else
						{
							
							if((Params.GATEcompare1.equals("Greater Than"))&&(regData.getGateScore()!=null)&&(Double.compare(regData.getGateScore(),Params.refGATEscore)>0))
							{
								b24 =true;
							}
							
						    if((Params.GATEcompare2.equals("Equals"))  && (regData.getGateScore()!=null)&&( Double.compare(regData.getGateScore(),Params.refGATEscore)==0))
						    {
						    	b24=true;
						    }
							
						    if(	(Params.GATEcompare3.equals("Lesser Than"))  &&(regData.getGateScore()!=null)&&( Double.compare(regData.getGateScore(), Params.refGATEscore) <0))
						    {
						    	b24=true;
						    }
						
						
						}
					
					
					
				if((Params.Applicationdatedupto!=null)&& (regData.getRegistrationDate().isEqual(Params.Applicationdatedupto)))
					b23=true;
				else
				if((Params.Applicationdatedfrom!=null)&&(regData.getRegistrationDate().isEqual(Params.Applicationdatedfrom)))
					b23=true;
				else
				if((Params.Applicationdatedfrom==null) && (Params.Applicationdatedupto==null))
					b23=true;
				else
				if((Params.Applicationdatedfrom==null) && (Params.Applicationdatedupto!=null)&&(regData.getRegistrationDate().isBefore(Params.Applicationdatedupto)))
				    b23=true;
				else
				if((Params.Applicationdatedfrom!=null)&&(regData.getRegistrationDate().isAfter(Params.Applicationdatedfrom)) && (Params.Applicationdatedupto==null))
					b23=true;
				else
				if((Params.Applicationdatedfrom!=null)&& (regData.getRegistrationDate().isAfter(Params.Applicationdatedfrom)) && (Params.Applicationdatedupto!=null )&&(regData.getRegistrationDate().isBefore(Params.Applicationdatedupto)))
					b23=true;
				else
					b23=false;
				

				System.out.println("single doFilter started 10");
				
				return b1&&b2&&b3&&b4&&b5&&b6&&b7&&b8&&b9&&b10&&b11&&b12&&b13&&b14&&b15&&b16&&b17&&b18&&b19&&b20&&b21&&b22&&b23&&b24;
				
				
				
		}

		
	ArrayList doFilter( FilterParams params  )
	{
		 System.out.println("doFilter started 1");
			
		
		System.out.println("doFilter started 2");
		ArrayList<Registration> Reg= new ArrayList<Registration>();
		System.out.println("doFilter started 3");
	    Reg= data_manager.DataManager.getAllRegistrations();
		ArrayList<Registration> newList = new ArrayList<Registration>();
		//Registration r1=readFromFile(3);
		//newList.add(r1);
		System.out.println("doFilter started 4");
		for(Registration r : Reg )
		{
			System.out.println("doFilter started 5");
			if(singleFilter(r,params))
				{
				   newList.add(r);
				   System.out.println("FOUND !!! "+r.toString());
				}
		}
		System.out.println("doFilter started 6");

		return newList;

	}

		
		
	
		
	}







